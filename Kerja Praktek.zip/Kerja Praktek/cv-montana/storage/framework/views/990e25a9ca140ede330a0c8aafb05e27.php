<!DOCTYPE html>
<html>
<head>
    <title>Nota <?php echo e($transaksi->nomor_nota); ?></title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; margin: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        table, th, td { border: 1px solid black; }
        th, td { padding: 5px; text-align: left; }
        .text-right { text-align: right; }
        .header { margin-bottom: 20px; }
        .header h2 { margin: 0; }
        .header p { margin: 2px 0; }
        tfoot th { background-color: #f0f0f0; }
    </style>
</head>
<body>
    <div class="header">
        <h2>CV Montana</h2>
        <p><strong>Nota:</strong> <?php echo e($transaksi->nomor_nota); ?></p>
        <p><strong>Tanggal:</strong> <?php echo e($transaksi->tanggal ? \Carbon\Carbon::parse($transaksi->tanggal)->format('d-m-Y H:i') : $transaksi->created_at->format('d-m-Y H:i')); ?></p>
        <p><strong>Sales:</strong> <?php echo e($transaksi->user->name ?? '-'); ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Barang</th>
                <th>Satuan</th>
                <th>Jumlah</th>
                <th>Harga Satuan</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php $total = 0; ?>
            <?php $__currentLoopData = $transaksi->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $total += $item->subtotal; ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($item->barang->nama_barang ?? '-'); ?></td>
                    <td><?php echo e($item->satuan->nama_satuan ?? '-'); ?></td>
                    <td class="text-right"><?php echo e($item->jumlah); ?></td>
                    <td class="text-right">Rp <?php echo e(number_format($item->harga_satuan,0,',','.')); ?></td>
                    <td class="text-right">Rp <?php echo e(number_format($item->subtotal,0,',','.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <th colspan="5" class="text-right">Total</th>
                <th class="text-right">Rp <?php echo e(number_format($total,0,',','.')); ?></th>
            </tr>
        </tfoot>
    </table>

    <p style="margin-top:20px;">Terima kasih atas pembelian Anda!</p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Kerja Praktek\cv-montana\resources\views/sales/transaksi/nota.blade.php ENDPATH**/ ?>