

<?php $__env->startSection('title','Edit Supplier'); ?>

<?php $__env->startSection('content'); ?>
<h2>Edit Supplier</h2>

<form action="/supplier/<?php echo e($supplier->id); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <p>Nama Supplier</p>
    <input type="text" name="nama_supplier" value="<?php echo e($supplier->nama_supplier); ?>" required>

    <p>Alamat</p>
    <textarea name="alamat" rows="3"><?php echo e($supplier->alamat); ?></textarea>

    <p>No. Telepon</p>
    <input type="text" name="telepon" value="<?php echo e($supplier->telepon); ?>">

    <br><br>
    <button type="submit">Update</button>
    <a href="/supplier">Batal</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Kerja Praktek\cv-montana\resources\views/gudang/supplier_edit.blade.php ENDPATH**/ ?>