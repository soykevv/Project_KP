

<?php $__env->startSection('title','Data Supplier'); ?>

<?php $__env->startSection('content'); ?>
<h2>Data Supplier</h2>

<a href="/supplier/tambah">+ Tambah Supplier</a>

<table border="1" cellpadding="8">
    <tr>
        <th>Nama</th>
        <th>Alamat</th>
        <th>No Telp</th>
        <th>Aksi</th>
    </tr>

    <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($s->nama_supplier); ?></td>
        <td><?php echo e($s->alamat); ?></td>
        <td><?php echo e($s->no_telp); ?></td>
        <td>
            <a href="/supplier/<?php echo e($s->id); ?>/edit">Edit</a>
            <form action="/supplier/<?php echo e($s->id); ?>" method="POST" style="display:inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button onclick="return confirm('Hapus supplier?')">Hapus</button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Kerja Praktek\cv-montana\resources\views/gudang/supplier.blade.php ENDPATH**/ ?>