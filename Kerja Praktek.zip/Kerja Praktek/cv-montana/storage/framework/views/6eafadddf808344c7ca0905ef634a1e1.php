

<?php $__env->startSection('title','Data Transaksi'); ?>

<?php $__env->startSection('content'); ?>
<h2>Riwayat Transaksi</h2>

<?php if(session('success')): ?>
    <p style="color:green"><?php echo e(session('success')); ?></p>
<?php endif; ?>

<table border="1" cellpadding="8">
    <tr>
        <th>No</th>
        <th>Nota</th>
        <th>Tanggal</th>
        <th>Total</th>
        <th>Sales</th>
        <th>Aksi</th>
    </tr>

    <?php $__empty_1 = true; $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($t->nomor_nota); ?></td>
        <td><?php echo e($t->tanggal); ?></td>
        <td>Rp <?php echo e(number_format($t->total_harga)); ?></td>
        <td><?php echo e($t->user->name ?? '-'); ?></td>
        <td>
            <a href="<?php echo e(route('transaksi.cetak', $t->id)); ?>" 
            target="_blank">Cetak Nota</a>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <tr>
        <td colspan="6">Belum ada transaksi</td>
    </tr>
    <?php endif; ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Kerja Praktek\cv-montana\resources\views/sales/transaksi/index.blade.php ENDPATH**/ ?>