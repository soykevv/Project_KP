

<?php $__env->startSection('title', 'Log Aktivitas'); ?>

<?php $__env->startSection('content'); ?>
<h2>Log Aktivitas</h2>

<style>
    table {
        width: 100%;
        border-collapse: collapse;
    }
    th, td {
        padding: 8px;
        border: 1px solid #ccc;
        text-align: left;
    }
    thead {
        background: #007bff;
        color: #fff;
    }
    .bg-masuk { background: #d4edda; }        /* hijau muda */
    .bg-keluar { background: #f8d7da; }      /* merah muda */
    .bg-penyesuaian { background: #fff3cd; } /* kuning muda */
    .bg-lain { background: #e2e3e5; }        /* abu muda */
</style>

<table>
    <thead>
        <tr>
            <th>No</th>
            <th>User</th>
            <th>Barang / Supplier</th>
            <th>Tipe Aktivitas</th>
            <th>Jumlah</th>
            <th>Keterangan</th>
            <th>Tanggal</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
            // Tentukan warna baris berdasarkan tipe aktivitas
            switch($log->tipe_aktivitas) {
                case 'barang_masuk': $class = 'bg-masuk'; break;
                case 'barang_keluar': $class = 'bg-keluar'; break;
                case 'penyesuaian': $class = 'bg-penyesuaian'; break;
                default: $class = 'bg-lain'; break;
            }

            // Tampilkan nama barang atau supplier
            if($log->barang) {
                $namaObjek = $log->barang->nama_barang;
            } elseif(str_contains($log->tipe_aktivitas, 'supplier')) {
                // Ambil nama supplier dari keterangan
                $namaObjek = preg_replace('/Menambahkan|Mengubah|Menghapus supplier: /', '', $log->keterangan);
            } else {
                $namaObjek = '-';
            }
        ?>
        <tr class="<?php echo e($class); ?>">
            <td><?php echo e($index + 1); ?></td>
            <td><?php echo e($log->user->name ?? '-'); ?></td>
            <td><?php echo e($namaObjek ?? '-'); ?></td>
            <td><?php echo e(ucfirst(str_replace('_',' ', $log->tipe_aktivitas))); ?></td>
            <td><?php echo e($log->jumlah); ?></td>
            <td><?php echo e($log->keterangan ?? '-'); ?></td>
            <td><?php echo e(\Carbon\Carbon::parse($log->tanggal)->format('d-m-Y')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="8" style="text-align:center;">Belum ada log aktivitas</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Kerja Praktek\cv-montana\resources\views/gudang/log_aktivitas.blade.php ENDPATH**/ ?>