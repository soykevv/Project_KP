

<?php $__env->startSection('title', 'Dashboard Gudang'); ?>

<?php $__env->startSection('content'); ?>
<h1>Dashboard Gudang</h1>
<p>Halo <?php echo e(auth()->user()->nama); ?></p>

<hr>

<div style="display:flex; gap:20px; margin-bottom:30px">

    <div style="border:1px solid #ccc; padding:15px; width:200px">
        <h3>Total Barang</h3>
        <p><?php echo e($totalBarang); ?></p>
    </div>

    <div style="border:1px solid #ccc; padding:15px; width:200px">
        <h3>Total Supplier</h3>
        <p><?php echo e($totalSupplier); ?></p>
    </div>

    <div style="border:1px solid #ccc; padding:15px; width:200px">
        <h3>Total Stok</h3>
        <p><?php echo e($totalStok); ?></p>
    </div>

</div>

<h3>Aktivitas Terakhir</h3>

<table border="1" cellpadding="8" width="100%">
    <tr>
        <th>Tanggal</th>
        <th>User</th>
        <th>Aktivitas</th>
        <th>Barang</th>
        <th>Keterangan</th>
    </tr>

    <?php $__currentLoopData = $logTerakhir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($log->tanggal); ?> <?php echo e($log->waktu); ?></td>
        <td><?php echo e($log->user->nama); ?></td>
        <td><?php echo e($log->tipe_aktivitas); ?></td>
        <td><?php echo e($log->barang->nama_barang ?? '-'); ?></td>
        <td><?php echo e($log->keterangan); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Kerja Praktek\cv-montana\resources\views/gudang/dashboard.blade.php ENDPATH**/ ?>