

<?php $__env->startSection('title','Tambah Barang'); ?>

<?php $__env->startSection('content'); ?>
<h2>Tambah Barang</h2>

<form action="/barang" method="POST">
    <?php echo csrf_field(); ?>

    <p>Nama Barang</p>
    <input type="text" name="nama_barang">

    <p>Kategori</p>
    <select name="kategori_id">
        <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama_kategori); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <p>Supplier</p>
    <select name="supplier_id">
        <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($s->id); ?>"><?php echo e($s->nama_supplier); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <p>Satuan</p>
    <select name="barang_satuan_id" required>
        <option value="">-- Pilih Satuan --</option>
        <?php $__currentLoopData = $satuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($s->id); ?>">
                <?php echo e($s->nama_satuan); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>


    <p>Jumlah Barang</p>
    <input type="number" name="stok">

    <p>Harga Awal</p>
    <input type="number" name="harga_awal">

    <br><br>
    <button type="submit">Simpan</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Kerja Praktek\cv-montana\resources\views/gudang/barang_tambah.blade.php ENDPATH**/ ?>