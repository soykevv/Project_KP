<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title', 'Sistem Inventori CV. Montana Intercontinental'); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background: #f4f6f8;
        }
        .navbar {
            background: #2c3e50;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            margin-right: 15px;
        }
        .navbar .left a:hover {
            text-decoration: underline;
        }
        .content {
            padding: 20px;
        }
        .logout-btn {
            background: #e74c3c;
            border: none;
            color: white;
            padding: 8px 12px;
            cursor: pointer;
        }
        .logout-btn:hover {
            background: #c0392b;
        }
        .badge {
            background: #3498db;
            padding: 5px 10px;
            border-radius: 10px;
            font-size: 12px;
        }
        .container {
            display: flex;
        }

        .sidebar {
            width: 220px;
            background: #34495e;
            color: white;
            min-height: 100vh;
            padding: 20px;
        }

        .sidebar h3 {
            margin-top: 0;
        }

        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            margin: 10px 0;
        }

        .sidebar a:hover {
            text-decoration: underline;
        }

        .main-content {
            flex: 1;
            padding: 20px;
        }

    </style>
</head>
<body>

    
    <div class="navbar">
        <div class="left">
            <strong>CV. Montana Intercontinental</strong>

            <?php if(auth()->guard()->check()): ?>
                <?php if(auth()->user()->role == 'gudang'): ?>
                    <a href="/dashboard-gudang">Dashboard Gudang</a>
                <?php elseif(auth()->user()->role == 'sales'): ?>
                    <a href="/dashboard-sales">Dashboard Sales</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <div class="right">
            <?php if(auth()->guard()->check()): ?>
                <span>
                    <?php echo e(auth()->user()->nama); ?>

                    <span class="badge"><?php echo e(auth()->user()->role); ?></span>
                </span>

                <form action="/logout" method="POST" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <button class="logout-btn" type="submit">Logout</button>
                </form>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="container">

        
        <?php if(auth()->guard()->check()): ?>
            <?php if(auth()->user()->role == 'gudang'): ?>
                <div class="sidebar">
                    <h3>Menu Gudang</h3>

                    <a href="/dashboard-gudang">Dashboard</a>
                    <a href="/barang">Data Barang</a>
                    <a href="/barang/tambah">Tambah Barang</a>
                    <a href="/supplier">Supplier</a>
                    <a href="/log-aktivitas">Log Aktivitas</a>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        
        <?php if(auth()->guard()->check()): ?>
            <?php if(auth()->user()->role == 'sales'): ?>
                <div class="sidebar">
                    <h3>Menu Sales</h3>

                    <a href="/dashboard-sales">Dashboard</a>
                    <a href="/transaksi/tambah">Transaksi Baru</a>
                    <a href="/transaksi">Riwayat Transaksi</a>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        
        <div class="main-content">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

    </div>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\Kerja Praktek\cv-montana\resources\views/layouts/app.blade.php ENDPATH**/ ?>