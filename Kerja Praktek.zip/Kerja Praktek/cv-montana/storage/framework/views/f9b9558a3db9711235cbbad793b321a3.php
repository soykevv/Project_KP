

<?php $__env->startSection('title','Data Barang'); ?>

<?php $__env->startSection('content'); ?>
<h2>Data Barang</h2>

<a href="/barang/tambah">+ Tambah Barang</a>

<table border="1" cellpadding="8">
    <tr>
        <th>No</th>
        <th>Nama</th>
        <th>Kategori</th>
        <th>Supplier</th>
        <th>Stok</th>
        <th>Harga Awal</th>
        <th>Aksi</th>
    </tr>

    <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($b->nama_barang); ?></td>
        <td><?php echo e($b->kategori->nama_kategori ?? '-'); ?></td>
        <td><?php echo e($b->supplier->nama_supplier ?? '-'); ?></td>
        <td><?php echo e($b->stok); ?><?php echo e($b->satuanDasar->nama_satuan ?? ''); ?></td>
        <td>Rp <?php echo e(number_format($b->harga_awal)); ?></td>
        <td>
            <a href="/barang/<?php echo e($b->id); ?>/edit">Edit</a>
            <form action="/barang/<?php echo e($b->id); ?>" method="POST" style="display:inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button onclick="return confirm('Hapus?')">Hapus</button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Kerja Praktek\cv-montana\resources\views/gudang/barang.blade.php ENDPATH**/ ?>